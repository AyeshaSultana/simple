define("dijit/form/nls/Textarea", { root:
//begin v1.x content
// used by both the editor and textarea widgets to provide information to screen reader users
({
	iframeEditTitle: 'edit area',  // primary title for editable IFRAME, for screen readers when focus is in the editing area
	iframeFocusTitle: 'edit area frame'  // secondary title for editable IFRAME when focus is on outer container
									 //  to let user know that focus has moved out of editing area and to the
									 //  parent element of the editing area
})
//end v1.x content
,
"zh": true,
"zh-tw": true,
"uk": true,
"tr": true,
"th": true,
"sv": true,
"sl": true,
"sk": true,
"ru": true,
"ro": true,
"pt": true,
"pt-pt": true,
"pl": true,
"nl": true,
"nb": true,
"ko": true,
"kk": true,
"ja": true,
"it": true,
"hu": true,
"hr": true,
"he": true,
"fr": true,
"fi": true,
"es": true,
"el": true,
"de": true,
"da": true,
"cs": true,
"ca": true,
"bg": true,
"az": true,
"ar": true
});
